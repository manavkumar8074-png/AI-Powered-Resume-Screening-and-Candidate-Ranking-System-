import { and, desc, eq, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  auditEvents,
  candidateProfiles,
  candidateReviews,
  candidates,
  hiringProjects,
  InsertUser,
  screeningResults,
  users,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  for (const field of textFields) {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  }
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  values.lastSignedIn ??= new Date();
  updateSet.lastSignedIn ??= new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function listProjects(ownerId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select({
      id: hiringProjects.id,
      title: hiringProjects.title,
      status: hiringProjects.status,
      jobProfile: hiringProjects.jobProfile,
      createdAt: hiringProjects.createdAt,
      updatedAt: hiringProjects.updatedAt,
      candidateCount: sql<number>`(SELECT COUNT(*) FROM candidates c WHERE c.projectId = ${hiringProjects.id})`,
      screenedCount: sql<number>`(SELECT COUNT(*) FROM candidates c WHERE c.projectId = ${hiringProjects.id} AND c.processingStatus = 'screened')`,
    })
    .from(hiringProjects)
    .where(eq(hiringProjects.ownerId, ownerId))
    .orderBy(desc(hiringProjects.updatedAt));
}

export async function getProject(ownerId: number, projectId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(hiringProjects)
    .where(and(eq(hiringProjects.id, projectId), eq(hiringProjects.ownerId, ownerId)))
    .limit(1);
  return result[0];
}

export async function createProject(values: typeof hiringProjects.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const result = await db.insert(hiringProjects).values(values);
  return Number((result as unknown as { insertId: number }).insertId);
}

export async function updateProject(ownerId: number, projectId: number, values: Partial<typeof hiringProjects.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(hiringProjects).set(values).where(and(eq(hiringProjects.id, projectId), eq(hiringProjects.ownerId, ownerId)));
}

export async function deleteProject(ownerId: number, projectId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const owned = await getProject(ownerId, projectId);
  if (!owned) return false;
  const projectCandidates = await db.select({ id: candidates.id }).from(candidates).where(eq(candidates.projectId, projectId));
  for (const candidate of projectCandidates) {
    await db.delete(candidateReviews).where(eq(candidateReviews.candidateId, candidate.id));
    await db.delete(screeningResults).where(eq(screeningResults.candidateId, candidate.id));
    await db.delete(candidateProfiles).where(eq(candidateProfiles.candidateId, candidate.id));
    await db.delete(auditEvents).where(eq(auditEvents.candidateId, candidate.id));
  }
  await db.delete(candidates).where(eq(candidates.projectId, projectId));
  await db.delete(auditEvents).where(eq(auditEvents.projectId, projectId));
  await db.delete(hiringProjects).where(eq(hiringProjects.id, projectId));
  return true;
}

export async function listRankedCandidates(ownerId: number, projectId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select({
      id: candidates.id,
      projectId: candidates.projectId,
      displayId: candidates.displayId,
      originalFilename: candidates.originalFilename,
      processingStatus: candidates.processingStatus,
      processingError: candidates.processingError,
      createdAt: candidates.createdAt,
      updatedAt: candidates.updatedAt,
      profile: candidateProfiles,
      result: screeningResults,
      review: candidateReviews,
    })
    .from(candidates)
    .innerJoin(hiringProjects, eq(hiringProjects.id, candidates.projectId))
    .leftJoin(candidateProfiles, eq(candidateProfiles.candidateId, candidates.id))
    .leftJoin(screeningResults, eq(screeningResults.candidateId, candidates.id))
    .leftJoin(candidateReviews, eq(candidateReviews.candidateId, candidates.id))
    .where(and(eq(hiringProjects.ownerId, ownerId), eq(candidates.projectId, projectId)))
    .orderBy(desc(screeningResults.overallScore), desc(candidates.createdAt));
}

export async function getCandidate(ownerId: number, candidateId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select({ candidate: candidates, project: hiringProjects, profile: candidateProfiles, result: screeningResults, review: candidateReviews })
    .from(candidates)
    .innerJoin(hiringProjects, eq(hiringProjects.id, candidates.projectId))
    .leftJoin(candidateProfiles, eq(candidateProfiles.candidateId, candidates.id))
    .leftJoin(screeningResults, eq(screeningResults.candidateId, candidates.id))
    .leftJoin(candidateReviews, eq(candidateReviews.candidateId, candidates.id))
    .where(and(eq(candidates.id, candidateId), eq(hiringProjects.ownerId, ownerId)))
    .limit(1);
  return result[0];
}

export async function createCandidate(values: typeof candidates.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const result = await db.insert(candidates).values(values);
  return Number((result as unknown as { insertId: number }).insertId);
}

export async function updateCandidate(candidateId: number, values: Partial<typeof candidates.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(candidates).set(values).where(eq(candidates.id, candidateId));
}

export async function saveProfile(candidateId: number, values: Omit<typeof candidateProfiles.$inferInsert, "candidateId">) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(candidateProfiles).values({ candidateId, ...values }).onDuplicateKeyUpdate({ set: values });
}

export async function saveResult(candidateId: number, values: Omit<typeof screeningResults.$inferInsert, "candidateId">) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(screeningResults).values({ candidateId, ...values }).onDuplicateKeyUpdate({ set: values });
}

export async function saveReview(candidateId: number, reviewerId: number, status: "unreviewed" | "reviewed" | "shortlisted" | "archived", notes?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(candidateReviews).values({ candidateId, reviewerId, status, notes: notes ?? null }).onDuplicateKeyUpdate({ set: { reviewerId, status, notes: notes ?? null } });
}

export async function addAuditEvent(values: typeof auditEvents.$inferInsert) {
  const db = await getDb();
  if (!db) return;
  await db.insert(auditEvents).values(values);
}
