import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import {
  addAuditEvent,
  createCandidate,
  createProject,
  deleteProject,
  getCandidate,
  getProject,
  listProjects,
  listRankedCandidates,
  saveProfile,
  saveResult,
  saveReview,
  updateCandidate,
  updateProject,
} from "./db";
import { storageGetSignedUrl, storagePut } from "./storage";
import {
  evaluateCandidate,
  extractResumeText,
  parseJobDescription,
  parseResume,
  RESUME_LIMITS,
  type JobProfile,
} from "./resumeProcessing";

const jobProfileInput = z.object({
  summary: z.string().max(600),
  requiredSkills: z.array(z.string().trim().min(1).max(80)).max(40),
  preferredSkills: z.array(z.string().trim().min(1).max(80)).max(40),
  minYearsExperience: z.number().int().min(0).max(60),
  education: z.array(z.string().trim().min(1).max(120)).max(20),
  certifications: z.array(z.string().trim().min(1).max(120)).max(20),
  weights: z.object({
    skills: z.number().int().min(0).max(100),
    experience: z.number().int().min(0).max(100),
    education: z.number().int().min(0).max(100),
    evidence: z.number().int().min(0).max(100),
  }),
});

const ensureWeights = (profile: JobProfile) => {
  const total = profile.weights.skills + profile.weights.experience + profile.weights.education + profile.weights.evidence;
  if (total !== 100) throw new TRPCError({ code: "BAD_REQUEST", message: "Scoring weights must add up to 100." });
  return profile;
};

const getOwnedCandidate = async (ownerId: number, candidateId: number) => {
  const record = await getCandidate(ownerId, candidateId);
  if (!record) throw new TRPCError({ code: "NOT_FOUND", message: "Candidate not found." });
  return record;
};

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  screening: router({
    listProjects: protectedProcedure.query(({ ctx }) => listProjects(ctx.user.id)),
    getProject: protectedProcedure
      .input(z.object({ projectId: z.number().int().positive() }))
      .query(async ({ ctx, input }) => {
        const project = await getProject(ctx.user.id, input.projectId);
        if (!project) throw new TRPCError({ code: "NOT_FOUND", message: "Hiring project not found." });
        return project;
      }),
    createProject: protectedProcedure
      .input(z.object({ title: z.string().trim().min(2).max(180), jobDescription: z.string().trim().min(40).max(30_000) }))
      .mutation(async ({ ctx, input }) => {
        const { profile, modelId } = await parseJobDescription(input.jobDescription);
        const projectId = await createProject({
          ownerId: ctx.user.id,
          title: input.title,
          jobDescription: input.jobDescription.trim(),
          jobProfile: profile,
          status: "draft",
        });
        await addAuditEvent({ ownerId: ctx.user.id, projectId, eventType: "project.created", metadata: { modelId } });
        return { projectId };
      }),
    updateProjectDetails: protectedProcedure
      .input(z.object({ projectId: z.number().int().positive(), title: z.string().trim().min(2).max(180), jobDescription: z.string().trim().min(40).max(30_000) }))
      .mutation(async ({ ctx, input }) => {
        const project = await getProject(ctx.user.id, input.projectId);
        if (!project) throw new TRPCError({ code: "NOT_FOUND", message: "Hiring project not found." });
        await updateProject(ctx.user.id, input.projectId, { title: input.title, jobDescription: input.jobDescription });
        await addAuditEvent({ ownerId: ctx.user.id, projectId: input.projectId, eventType: "project.updated", metadata: { source: "recruiter" } });
        return { success: true } as const;
      }),
    updateJobProfile: protectedProcedure
      .input(z.object({ projectId: z.number().int().positive(), jobProfile: jobProfileInput }))
      .mutation(async ({ ctx, input }) => {
        const project = await getProject(ctx.user.id, input.projectId);
        if (!project) throw new TRPCError({ code: "NOT_FOUND", message: "Hiring project not found." });
        ensureWeights(input.jobProfile as JobProfile);
        await updateProject(ctx.user.id, input.projectId, { jobProfile: input.jobProfile, status: "draft" });
        await addAuditEvent({ ownerId: ctx.user.id, projectId: input.projectId, eventType: "job-profile.updated", metadata: { source: "recruiter" } });
        return { success: true } as const;
      }),
    deleteProject: protectedProcedure
      .input(z.object({ projectId: z.number().int().positive() }))
      .mutation(async ({ ctx, input }) => {
        const deleted = await deleteProject(ctx.user.id, input.projectId);
        if (!deleted) throw new TRPCError({ code: "NOT_FOUND", message: "Hiring project not found." });
        return { success: true } as const;
      }),
    listCandidates: protectedProcedure
      .input(z.object({ projectId: z.number().int().positive() }))
      .query(async ({ ctx, input }) => {
        const project = await getProject(ctx.user.id, input.projectId);
        if (!project) throw new TRPCError({ code: "NOT_FOUND", message: "Hiring project not found." });
        return listRankedCandidates(ctx.user.id, input.projectId);
      }),
    getCandidate: protectedProcedure
      .input(z.object({ candidateId: z.number().int().positive() }))
      .query(async ({ ctx, input }) => getOwnedCandidate(ctx.user.id, input.candidateId)),
    uploadResume: protectedProcedure
      .input(z.object({
        projectId: z.number().int().positive(),
        filename: z.string().trim().min(1).max(255),
        mimeType: z.string().trim().min(1).max(120),
        fileData: z.string().min(1),
      }))
      .mutation(async ({ ctx, input }) => {
        const project = await getProject(ctx.user.id, input.projectId);
        if (!project) throw new TRPCError({ code: "NOT_FOUND", message: "Hiring project not found." });
        if (!RESUME_LIMITS.allowedMimeTypes.includes(input.mimeType as (typeof RESUME_LIMITS.allowedMimeTypes)[number])) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Only PDF and DOCX resumes are supported." });
        }
        let buffer: Buffer;
        try {
          buffer = Buffer.from(input.fileData, "base64");
        } catch {
          throw new TRPCError({ code: "BAD_REQUEST", message: "The uploaded file could not be decoded." });
        }
        if (buffer.length === 0 || buffer.length > RESUME_LIMITS.maxBytes) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Resume must be between 1 byte and 10 MB." });
        }
        const displayId = `CAND-${crypto.randomUUID().replace(/-/g, "").slice(0, 8).toUpperCase()}`;
        const stored = await storagePut(`projects/${ctx.user.id}/${input.projectId}/resumes/${input.filename}`, buffer, input.mimeType);
        const candidateId = await createCandidate({
          projectId: input.projectId,
          originalFilename: input.filename,
          displayId,
          storageKey: stored.key,
          mimeType: input.mimeType,
          fileSize: buffer.length,
          processingStatus: "queued",
        });
        try {
          await updateCandidate(candidateId, { processingStatus: "parsing", processingError: null });
          const extractedText = await extractResumeText(buffer, input.mimeType, input.filename);
          const { profile, modelId } = await parseResume(extractedText);
          const rawJobProfile = project.jobProfile && typeof project.jobProfile === "object" ? project.jobProfile as JobProfile : null;
          const jobProfile = rawJobProfile ?? (await parseJobDescription(project.jobDescription)).profile;
          const evaluation = evaluateCandidate(profile, ensureWeights(jobProfile), extractedText);
          await updateCandidate(candidateId, { extractedText, processingStatus: "screened", processingError: null });
          await saveProfile(candidateId, {
            fullName: profile.fullName,
            email: profile.email,
            location: profile.location,
            headline: profile.headline,
            skills: profile.skills,
            experience: profile.experience,
            education: profile.education,
            certifications: profile.certifications,
            totalYearsExperience: Math.round(profile.totalYearsExperience),
            extractionConfidence: profile.confidence,
            modelId,
            schemaVersion: "resume-profile-v1",
          });
          await saveResult(candidateId, {
            overallScore: evaluation.overallScore,
            skillsScore: evaluation.skillsScore,
            experienceScore: evaluation.experienceScore,
            educationScore: evaluation.educationScore,
            evidenceScore: evaluation.evidenceScore,
            matchedRequirements: evaluation.matchedRequirements,
            missingRequirements: evaluation.missingRequirements,
            evidenceSnippets: evaluation.evidenceSnippets,
            uncertaintyFlags: evaluation.uncertaintyFlags,
            modelId,
            promptVersion: "screening-v1",
            generatedAt: new Date(),
          });
          await saveReview(candidateId, ctx.user.id, "unreviewed");
          await updateProject(ctx.user.id, input.projectId, { status: "complete" });
          await addAuditEvent({ ownerId: ctx.user.id, projectId: input.projectId, candidateId, eventType: "candidate.screened", metadata: { modelId, overallScore: evaluation.overallScore } });
          return { candidateId, displayId, status: "screened" as const, score: evaluation.overallScore };
        } catch (error) {
          const message = error instanceof Error ? error.message : "Resume processing failed.";
          await updateCandidate(candidateId, { processingStatus: "failed", processingError: message.slice(0, 500) });
          await addAuditEvent({ ownerId: ctx.user.id, projectId: input.projectId, candidateId, eventType: "candidate.failed", metadata: { message: message.slice(0, 200) } });
          throw new TRPCError({ code: "BAD_REQUEST", message });
        }
      }),
    retryScreening: protectedProcedure
      .input(z.object({ candidateId: z.number().int().positive() }))
      .mutation(async ({ ctx, input }) => {
        const record = await getOwnedCandidate(ctx.user.id, input.candidateId);
        await updateCandidate(input.candidateId, { processingStatus: "parsing", processingError: null });
        try {
          const signedUrl = await storageGetSignedUrl(record.candidate.storageKey);
          const response = await fetch(signedUrl);
          if (!response.ok) throw new Error("The stored resume could not be retrieved.");
          const buffer = Buffer.from(await response.arrayBuffer());
          const extractedText = await extractResumeText(buffer, record.candidate.mimeType, record.candidate.originalFilename);
          const { profile, modelId } = await parseResume(extractedText);
          const jobProfile = record.project.jobProfile && typeof record.project.jobProfile === "object" ? record.project.jobProfile as JobProfile : (await parseJobDescription(record.project.jobDescription)).profile;
          const evaluation = evaluateCandidate(profile, ensureWeights(jobProfile), extractedText);
          await updateCandidate(input.candidateId, { extractedText, processingStatus: "screened", processingError: null });
          await saveProfile(input.candidateId, { fullName: profile.fullName, email: profile.email, location: profile.location, headline: profile.headline, skills: profile.skills, experience: profile.experience, education: profile.education, certifications: profile.certifications, totalYearsExperience: Math.round(profile.totalYearsExperience), extractionConfidence: profile.confidence, modelId, schemaVersion: "resume-profile-v1" });
          await saveResult(input.candidateId, { overallScore: evaluation.overallScore, skillsScore: evaluation.skillsScore, experienceScore: evaluation.experienceScore, educationScore: evaluation.educationScore, evidenceScore: evaluation.evidenceScore, matchedRequirements: evaluation.matchedRequirements, missingRequirements: evaluation.missingRequirements, evidenceSnippets: evaluation.evidenceSnippets, uncertaintyFlags: evaluation.uncertaintyFlags, modelId, promptVersion: "screening-v1", generatedAt: new Date() });
          await addAuditEvent({ ownerId: ctx.user.id, projectId: record.candidate.projectId, candidateId: input.candidateId, eventType: "candidate.retried", metadata: { modelId, overallScore: evaluation.overallScore } });
          return { success: true, score: evaluation.overallScore } as const;
        } catch (error) {
          const message = error instanceof Error ? error.message : "Resume processing failed.";
          await updateCandidate(input.candidateId, { processingStatus: "failed", processingError: message.slice(0, 500) });
          throw new TRPCError({ code: "BAD_REQUEST", message });
        }
      }),
    updateReview: protectedProcedure
      .input(z.object({ candidateId: z.number().int().positive(), status: z.enum(["unreviewed", "reviewed", "shortlisted", "archived"]), notes: z.string().max(4_000).optional() }))
      .mutation(async ({ ctx, input }) => {
        const record = await getOwnedCandidate(ctx.user.id, input.candidateId);
        await saveReview(input.candidateId, ctx.user.id, input.status, input.notes);
        await addAuditEvent({ ownerId: ctx.user.id, projectId: record.candidate.projectId, candidateId: input.candidateId, eventType: "candidate.reviewed", metadata: { status: input.status } });
        return { success: true } as const;
      }),
    updateNotes: protectedProcedure
      .input(z.object({ candidateId: z.number().int().positive(), notes: z.string().max(4_000) }))
      .mutation(async ({ ctx, input }) => {
        const record = await getOwnedCandidate(ctx.user.id, input.candidateId);
        await saveReview(input.candidateId, ctx.user.id, record.review?.status ?? "reviewed", input.notes);
        return { success: true } as const;
      }),
  }),
});

export type AppRouter = typeof appRouter;
