import { describe, expect, it, vi } from "vitest";

vi.mock("pdf-parse", () => ({ PDFParse: class { constructor(_: unknown) {} async getText() { return { text: "Alex Rivera\\nPython machine learning" }; } async destroy() {} } }));
vi.mock("mammoth", () => ({ default: { extractRawText: async () => ({ value: "Alex Rivera\\nDOCX resume content" }) } }));

import { evaluateCandidate, extractResumeText, type JobProfile, type ResumeProfile } from "./resumeProcessing";

const job: JobProfile = {
  summary: "Senior ML role",
  requiredSkills: ["Python", "Machine Learning"],
  preferredSkills: ["AWS"],
  minYearsExperience: 3,
  education: ["Bachelor's degree"],
  certifications: [],
  weights: { skills: 45, experience: 30, education: 15, evidence: 10 },
};

const profile: ResumeProfile = {
  fullName: "Alex Rivera",
  email: "alex@example.com",
  location: "Bengaluru",
  headline: "Machine learning engineer",
  skills: ["Python", "Machine Learning", "AWS"],
  experience: [{ company: "Northstar", title: "ML Engineer", years: 4, highlights: ["Built NLP models"] }],
  education: ["Bachelor's degree in Computer Science"],
  certifications: [],
  totalYearsExperience: 4,
  confidence: 90,
};

describe("evaluateCandidate", () => {
  it("returns a high, explainable score for an evidence-backed match", () => {
    const result = evaluateCandidate(profile, job, "Alex Rivera\nPython machine learning AWS bachelor's degree 4 years");
    expect(result.overallScore).toBeGreaterThanOrEqual(80);
    expect(result.matchedRequirements).toEqual(expect.arrayContaining(["Skill: Python", "Skill: Machine Learning"]));
    expect(result.missingRequirements).not.toContain("Skill: Python");
    expect(result.evidenceSnippets.find(item => item.requirement === "Skill: Python")?.evidence.toLowerCase()).toContain("python");
  });

  it("flags missing evidence instead of inventing a match", () => {
    const result = evaluateCandidate({ ...profile, skills: [], totalYearsExperience: 0, confidence: 35 }, job, "Short profile");
    expect(result.overallScore).toBeLessThan(60);
    expect(result.missingRequirements).toEqual(expect.arrayContaining(["Skill: Python", "Experience: 3+ years"]));
    expect(result.uncertaintyFlags.length).toBeGreaterThan(0);
  });
});

describe("extractResumeText validation", () => {
  it("rejects unsupported file types before parsing", async () => {
    await expect(extractResumeText(Buffer.from("resume"), "text/plain", "resume.txt")).rejects.toThrow("Only PDF and DOCX resumes are supported");
  });

  it("rejects files over the 10 MB limit", async () => {
    const oversized = Buffer.alloc(10 * 1024 * 1024 + 1);
    await expect(extractResumeText(oversized, "application/pdf", "resume.pdf")).rejects.toThrow("10 MB file limit");
  });

  it("extracts selectable text from a PDF", async () => {
    await expect(extractResumeText(Buffer.from("pdf"), "application/pdf", "resume.pdf")).resolves.toContain("Python machine learning");
  });

  it("extracts raw text from a DOCX", async () => {
    await expect(extractResumeText(Buffer.from("docx"), "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "resume.docx")).resolves.toContain("DOCX resume content");
  });
});
