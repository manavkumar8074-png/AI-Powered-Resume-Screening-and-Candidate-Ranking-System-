import { beforeEach, describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";

vi.mock("./db", () => ({
  addAuditEvent: vi.fn(),
  createCandidate: vi.fn(),
  createProject: vi.fn(),
  deleteProject: vi.fn(),
  getCandidate: vi.fn(),
  getProject: vi.fn(),
  listProjects: vi.fn(),
  listRankedCandidates: vi.fn(),
  saveProfile: vi.fn(),
  saveResult: vi.fn(),
  saveReview: vi.fn(),
  updateCandidate: vi.fn(),
  updateProject: vi.fn(),
}));
vi.mock("./storage", () => ({ storagePut: vi.fn(), storageGetSignedUrl: vi.fn() }));
vi.mock("./resumeProcessing", () => ({
  RESUME_LIMITS: { maxBytes: 10 * 1024 * 1024, allowedMimeTypes: ["application/pdf", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"] },
  evaluateCandidate: vi.fn(),
  extractResumeText: vi.fn(),
  parseJobDescription: vi.fn(),
  parseResume: vi.fn(),
}));

import { appRouter } from "./routers";
import { addAuditEvent, createProject, deleteProject, getCandidate, getProject, listProjects, listRankedCandidates, saveReview, updateCandidate, updateProject } from "./db";
import { evaluateCandidate, extractResumeText, parseJobDescription, parseResume } from "./resumeProcessing";
import { storageGetSignedUrl } from "./storage";

const profile = {
  summary: "ML role",
  requiredSkills: ["Python"],
  preferredSkills: [],
  minYearsExperience: 2,
  education: [],
  certifications: [],
  weights: { skills: 45, experience: 30, education: 15, evidence: 10 },
};

const context = { user: { id: 7, openId: "owner", name: "Owner", email: "owner@example.com", loginMethod: "manus", role: "user", createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() }, req: {}, res: {} } as TrpcContext;

describe("screening procedures", () => {
  beforeEach(() => vi.clearAllMocks());

  it("creates a project from a normalized job description", async () => {
    vi.mocked(parseJobDescription).mockResolvedValue({ profile, modelId: "test-model" });
    vi.mocked(createProject).mockResolvedValue(42);
    const result = await appRouter.createCaller(context).screening.createProject({ title: "ML Engineer", jobDescription: "Build production machine learning systems with Python and NLP." });
    expect(result).toEqual({ projectId: 42 });
    expect(createProject).toHaveBeenCalledWith(expect.objectContaining({ ownerId: 7, title: "ML Engineer", jobProfile: profile }));
    expect(addAuditEvent).toHaveBeenCalled();
  });

  it("updates project details only when the project belongs to the recruiter", async () => {
    vi.mocked(getProject).mockResolvedValue({ id: 42, ownerId: 7, title: "Old", jobDescription: "A sufficiently long job description for the test case.", jobProfile: profile, status: "draft", createdAt: new Date(), updatedAt: new Date() });
    const result = await appRouter.createCaller(context).screening.updateProjectDetails({ projectId: 42, title: "New title", jobDescription: "A sufficiently long updated job description for the test case." });
    expect(result).toEqual({ success: true });
    expect(updateProject).toHaveBeenCalledWith(7, 42, expect.objectContaining({ title: "New title" }));
  });

  it("returns not found for a project outside the recruiter scope", async () => {
    vi.mocked(getProject).mockResolvedValue(undefined);
    await expect(appRouter.createCaller(context).screening.updateProjectDetails({ projectId: 999, title: "New title", jobDescription: "A sufficiently long updated job description for the test case." })).rejects.toMatchObject({ code: "NOT_FOUND" });
  });

  it("reads an owned project and candidate successfully", async () => {
    const project = { id: 42, ownerId: 7, title: "ML Engineer", jobDescription: "A sufficiently long job description for the test case.", jobProfile: profile, status: "complete", createdAt: new Date(), updatedAt: new Date() };
    vi.mocked(getProject).mockResolvedValue(project as any);
    vi.mocked(getCandidate).mockResolvedValue({ candidate: { id: 8, projectId: 42 }, project, profile: null, result: null, review: null } as any);
    await expect(appRouter.createCaller(context).screening.getProject({ projectId: 42 })).resolves.toMatchObject({ id: 42 });
    await expect(appRouter.createCaller(context).screening.getCandidate({ candidateId: 8 })).resolves.toMatchObject({ candidate: { id: 8 } });
  });

  it("lists and reads project-scoped results", async () => {
    vi.mocked(listProjects).mockResolvedValue([{ id: 42, title: "ML Engineer", status: "complete", jobProfile: profile, createdAt: new Date(), updatedAt: new Date(), candidateCount: 2, screenedCount: 2 }] as any);
    vi.mocked(getProject).mockResolvedValue({ id: 42, ownerId: 7, title: "ML Engineer", jobDescription: "A sufficiently long job description for the test case.", jobProfile: profile, status: "complete", createdAt: new Date(), updatedAt: new Date() });
    vi.mocked(listRankedCandidates).mockResolvedValue([] as any);
    await expect(appRouter.createCaller(context).screening.listProjects()).resolves.toHaveLength(1);
    await expect(appRouter.createCaller(context).screening.listCandidates({ projectId: 42 })).resolves.toEqual([]);
  });

  it("deletes an owned project", async () => {
    vi.mocked(deleteProject).mockResolvedValue(true);
    await expect(appRouter.createCaller(context).screening.deleteProject({ projectId: 42 })).resolves.toEqual({ success: true });
    expect(deleteProject).toHaveBeenCalledWith(7, 42);
  });

  it("persists review status and notes for an owned candidate", async () => {
    vi.mocked(getCandidate).mockResolvedValue({ candidate: { id: 8, projectId: 42 }, project: { id: 42, ownerId: 7 }, profile: null, result: null, review: null } as any);
    const result = await appRouter.createCaller(context).screening.updateReview({ candidateId: 8, status: "shortlisted", notes: "Strong evidence in required skills." });
    expect(result).toEqual({ success: true });
    expect(saveReview).toHaveBeenCalledWith(8, 7, "shortlisted", "Strong evidence in required skills.");
  });

  it("updates notes without changing an existing review status", async () => {
    vi.mocked(getCandidate).mockResolvedValue({ candidate: { id: 8, projectId: 42 }, project: { id: 42, ownerId: 7 }, profile: null, result: null, review: { status: "reviewed" } } as any);
    await expect(appRouter.createCaller(context).screening.updateNotes({ candidateId: 8, notes: "Follow up on NLP experience." })).resolves.toEqual({ success: true });
    expect(saveReview).toHaveBeenCalledWith(8, 7, "reviewed", "Follow up on NLP experience.");
  });

  it("retries a failed candidate through parsing and screening", async () => {
    vi.mocked(getCandidate).mockResolvedValue({ candidate: { id: 8, projectId: 42, storageKey: "resume-key", mimeType: "application/pdf", originalFilename: "resume.pdf" }, project: { id: 42, ownerId: 7, jobDescription: "A sufficiently long job description for the test case.", jobProfile: profile }, profile: null, result: null, review: null } as any);
    vi.mocked(storageGetSignedUrl).mockResolvedValue("https://example.com/resume.pdf");
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue({ ok: true, arrayBuffer: async () => new ArrayBuffer(4) }));
    vi.mocked(extractResumeText).mockResolvedValue("Python machine learning 4 years");
    vi.mocked(parseResume).mockResolvedValue({ profile: { fullName: "Alex", email: "", location: "", headline: "", skills: ["Python"], experience: [], education: [], certifications: [], totalYearsExperience: 4, confidence: 90 }, modelId: "test-model" });
    vi.mocked(evaluateCandidate).mockReturnValue({ overallScore: 88, skillsScore: 90, experienceScore: 100, educationScore: 70, evidenceScore: 90, matchedRequirements: ["Skill: Python"], missingRequirements: [], evidenceSnippets: [], uncertaintyFlags: [] });
    await expect(appRouter.createCaller(context).screening.retryScreening({ candidateId: 8 })).resolves.toEqual({ success: true, score: 88 });
    expect(updateCandidate).toHaveBeenCalledWith(8, expect.objectContaining({ processingStatus: "screened" }));
    vi.unstubAllGlobals();
  });

  it("marks a retry as failed when stored resume retrieval fails", async () => {
    vi.mocked(getCandidate).mockResolvedValue({ candidate: { id: 8, projectId: 42, storageKey: "resume-key", mimeType: "application/pdf", originalFilename: "resume.pdf" }, project: { id: 42, ownerId: 7, jobDescription: "A sufficiently long job description for the test case.", jobProfile: profile }, profile: null, result: null, review: null } as any);
    vi.mocked(storageGetSignedUrl).mockRejectedValue(new Error("Storage unavailable"));
    await expect(appRouter.createCaller(context).screening.retryScreening({ candidateId: 8 })).rejects.toMatchObject({ code: "BAD_REQUEST", message: "Storage unavailable" });
    expect(updateCandidate).toHaveBeenCalledWith(8, expect.objectContaining({ processingStatus: "failed", processingError: "Storage unavailable" }));
  });

  it("returns not found for an out-of-scope candidate retrieval", async () => {
    vi.mocked(getCandidate).mockResolvedValue(undefined);
    await expect(appRouter.createCaller(context).screening.getCandidate({ candidateId: 999 })).rejects.toMatchObject({ code: "NOT_FOUND" });
  });

  it("returns not found for an out-of-scope candidate review", async () => {
    vi.mocked(getCandidate).mockResolvedValue(undefined);
    await expect(appRouter.createCaller(context).screening.updateNotes({ candidateId: 999, notes: "Should not be accepted." })).rejects.toMatchObject({ code: "NOT_FOUND" });
  });
});
