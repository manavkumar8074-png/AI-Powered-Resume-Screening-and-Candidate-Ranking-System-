import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

const publicContext = {
  user: null,
  req: { protocol: "https", headers: {} },
  res: {},
} as TrpcContext;

describe("screening authorization", () => {
  it("requires authentication before listing hiring projects", async () => {
    const caller = appRouter.createCaller(publicContext);
    await expect(caller.screening.listProjects()).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("requires authentication before reading a candidate", async () => {
    const caller = appRouter.createCaller(publicContext);
    await expect(caller.screening.getCandidate({ candidateId: 1 })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });
});
