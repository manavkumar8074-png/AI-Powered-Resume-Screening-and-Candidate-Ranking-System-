# Scaffold Notes

The project uses the existing Manus full-stack template with React 19, Tailwind CSS, Express, tRPC, Drizzle ORM, MySQL/TiDB, Manus OAuth, and preconfigured private storage helpers. The current application exposes tRPC under `/api/trpc`; authenticated procedures use `protectedProcedure` and receive the authenticated user through `ctx.user`.

The implementation reuses `DashboardLayout` for authenticated recruiter navigation, the existing shadcn/ui component library for controls, dialogs, badges, tables, progress indicators, and toasts, and the existing `ThemeProvider`, `ErrorBoundary`, and authentication hooks. The client calls server functionality through the typed `trpc` client rather than introducing a separate REST or Axios layer.

On the server, `server/db.ts` owns database access helpers; `server/storage.ts` owns private S3-compatible storage through the built-in Forge storage proxy; `server/_core/llm.ts` provides the server-only `invokeLLM` helper; and `server/resumeProcessing.ts` contains parser validation, PDF/DOCX text extraction, structured JSON-schema extraction, deterministic score calculation, and heuristic fallbacks. The product data model lives in `drizzle/schema.ts` and the application procedures live in `server/routers.ts`.

The attached project deck describes the academic framing: NLP-based resume parsing, job-description matching, candidate scoring/ranking, a Python/Flask/MySQL/scikit-learn/spaCy/ NLTK reference stack, and SDG 8 (Decent Work and Economic Growth). The current web implementation preserves those concepts while using the managed full-stack scaffold and a transparent human-review workflow.
