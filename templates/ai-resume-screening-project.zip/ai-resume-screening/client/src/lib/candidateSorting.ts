export type SortableCandidate = {
  id: number;
  displayId: string;
  profile?: { fullName?: string | null } | null;
  result?: { overallScore?: number | null } | null;
};

export function sortCandidates<T extends SortableCandidate>(candidates: T[], sortBy: "score" | "name") {
  return [...candidates].sort((a, b) =>
    sortBy === "name"
      ? String(a.profile?.fullName || a.displayId).localeCompare(String(b.profile?.fullName || b.displayId))
      : (b.result?.overallScore ?? -1) - (a.result?.overallScore ?? -1),
  );
}
