import { describe, expect, it } from "vitest";
import { sortCandidates } from "./candidateSorting";

describe("sortCandidates", () => {
  const candidates = [
    { id: 1, displayId: "CAND-A", profile: { fullName: "Zoe" }, result: { overallScore: 72 } },
    { id: 2, displayId: "CAND-B", profile: { fullName: "Alex" }, result: { overallScore: 91 } },
    { id: 3, displayId: "CAND-C", profile: null, result: null },
  ];

  it("orders screened candidates by highest match score", () => {
    expect(sortCandidates(candidates, "score").map(candidate => candidate.id)).toEqual([2, 1, 3]);
  });

  it("orders candidates alphabetically by name with display-id fallback", () => {
    expect(sortCandidates(candidates, "name").map(candidate => candidate.id)).toEqual([2, 3, 1]);
  });
});
