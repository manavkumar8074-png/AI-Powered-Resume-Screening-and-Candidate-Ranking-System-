import DashboardLayout from "@/components/DashboardLayout";
import { useAuth } from "@/_core/hooks/useAuth";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";
import { sortCandidates } from "@/lib/candidateSorting";
import { trpc } from "@/lib/trpc";
import {
  AlertCircle,
  ArrowLeft,
  ArrowUpRight,
  BriefcaseBusiness,
  Check,
  ChevronRight,
  CircleHelp,
  FileText,
  Filter,
  Layers3,
  Loader2,
  Plus,
  Search,
  ShieldCheck,
  Sparkles,
  Target,
  UploadCloud,
  Users,
  X,
} from "lucide-react";
import { useMemo, useRef, useState } from "react";
import { toast } from "sonner";

const defaultProfile = {
  summary: "Requirements will appear after the job description is analyzed.",
  requiredSkills: [] as string[],
  preferredSkills: [] as string[],
  minYearsExperience: 0,
  education: [] as string[],
  certifications: [] as string[],
  weights: { skills: 45, experience: 30, education: 15, evidence: 10 },
};

type JobProfile = typeof defaultProfile;

const getProfile = (value: unknown): JobProfile => {
  if (!value || typeof value !== "object") return defaultProfile;
  const raw = value as Partial<JobProfile>;
  return {
    summary: typeof raw.summary === "string" ? raw.summary : defaultProfile.summary,
    requiredSkills: Array.isArray(raw.requiredSkills) ? raw.requiredSkills.map(String) : [],
    preferredSkills: Array.isArray(raw.preferredSkills) ? raw.preferredSkills.map(String) : [],
    minYearsExperience: Number(raw.minYearsExperience) || 0,
    education: Array.isArray(raw.education) ? raw.education.map(String) : [],
    certifications: Array.isArray(raw.certifications) ? raw.certifications.map(String) : [],
    weights: {
      skills: Number(raw.weights?.skills) || 45,
      experience: Number(raw.weights?.experience) || 30,
      education: Number(raw.weights?.education) || 15,
      evidence: Number(raw.weights?.evidence) || 10,
    },
  };
};

const scoreTone = (score: number) => score >= 80 ? "text-emerald-600" : score >= 60 ? "text-amber-600" : "text-slate-500";
const scoreBar = (score: number) => score >= 80 ? "bg-emerald-500" : score >= 60 ? "bg-amber-500" : "bg-slate-400";

function AppMark() {
  return <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#243b53] text-white shadow-sm"><Layers3 className="h-4 w-4" /></div>;
}

function StatCard({ label, value, detail, icon: Icon, accent }: { label: string; value: string | number; detail: string; icon: typeof Users; accent: string }) {
  return <Card className="border-0 bg-white/85 shadow-[0_8px_30px_rgba(31,56,78,0.06)]">
    <CardContent className="flex items-start justify-between p-5">
      <div><p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-slate-400">{label}</p><p className="mt-2 text-3xl font-semibold tracking-tight text-[#243b53]">{value}</p><p className="mt-1 text-xs text-slate-500">{detail}</p></div>
      <div className={`rounded-xl p-2.5 ${accent}`}><Icon className="h-4 w-4" /></div>
    </CardContent>
  </Card>;
}

function NewProject({ onCreated, onCancel }: { onCreated: (id: number) => void; onCancel: () => void }) {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const utils = trpc.useUtils();
  const create = trpc.screening.createProject.useMutation({
    onSuccess: async result => { toast.success("Role created and requirements analyzed"); await utils.screening.listProjects.invalidate(); onCreated(result.projectId); },
    onError: error => toast.error(error.message),
  });
  return <Card className="border-0 bg-white shadow-[0_14px_50px_rgba(31,56,78,0.10)]">
    <CardHeader className="border-b border-slate-100 bg-[#fbfcfd] p-6"><div className="flex items-center gap-3"><div className="rounded-xl bg-[#e7eef5] p-2.5 text-[#243b53]"><BriefcaseBusiness className="h-5 w-5" /></div><div><CardTitle className="text-lg text-[#243b53]">Create a hiring project</CardTitle><CardDescription>Start with the role brief. AI will extract explicit requirements for your review.</CardDescription></div></div></CardHeader>
    <CardContent className="space-y-6 p-6">
      <div className="space-y-2"><Label htmlFor="role-title">Role title</Label><Input id="role-title" value={title} onChange={e => setTitle(e.target.value)} placeholder="e.g. Senior Machine Learning Engineer" className="h-11" /></div>
      <div className="space-y-2"><div className="flex items-center justify-between"><Label htmlFor="role-description">Job description</Label><span className="text-xs text-slate-400">Minimum 40 characters</span></div><Textarea id="role-description" value={description} onChange={e => setDescription(e.target.value)} placeholder="Paste the full job description, including responsibilities and must-have skills…" className="min-h-52 resize-y leading-6" /></div>
      <div className="flex items-start gap-3 rounded-xl border border-[#dbe8f2] bg-[#f4f8fb] p-4 text-sm text-[#486581]"><ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-[#2f80a0]" /><p>Screening is designed for human review. Protected characteristics are excluded and each score is accompanied by evidence and uncertainty flags.</p></div>
      <div className="flex justify-end gap-3"><Button variant="ghost" onClick={onCancel}>Cancel</Button><Button disabled={create.isPending || title.trim().length < 2 || description.trim().length < 40} onClick={() => create.mutate({ title, jobDescription: description })} className="bg-[#243b53] hover:bg-[#1c2f43]">{create.isPending ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" />Analyzing role…</> : <><Sparkles className="mr-2 h-4 w-4" />Analyze & create</>}</Button></div>
    </CardContent>
  </Card>;
}

function JobProfileCard({ projectId, profile, onUpdated }: { projectId: number; profile: JobProfile; onUpdated: () => void }) {
  const [draft, setDraft] = useState(profile);
  const [newSkill, setNewSkill] = useState("");
  const update = trpc.screening.updateJobProfile.useMutation({ onSuccess: () => { toast.success("Requirements updated"); onUpdated(); }, onError: error => toast.error(error.message) });
  const addSkill = () => { const skill = newSkill.trim(); if (skill && !draft.requiredSkills.includes(skill)) { setDraft({ ...draft, requiredSkills: [...draft.requiredSkills, skill] }); setNewSkill(""); } };
  return <Card className="border-0 bg-white shadow-[0_8px_30px_rgba(31,56,78,0.06)]"><CardHeader className="pb-4"><div className="flex items-start justify-between gap-4"><div><CardTitle className="text-base text-[#243b53]">Role profile</CardTitle><CardDescription className="mt-1">Review what the parser found before screening resumes.</CardDescription></div><Badge variant="outline" className="gap-1 border-[#d5e4ef] bg-[#f5f9fc] text-[#486581]"><Sparkles className="h-3 w-3" />AI extracted</Badge></div></CardHeader><CardContent className="space-y-5">
    <p className="rounded-xl bg-[#f7fafc] p-3 text-sm leading-6 text-slate-600">{draft.summary}</p>
    <div><div className="mb-2 flex items-center justify-between"><p className="text-xs font-semibold uppercase tracking-[0.14em] text-slate-400">Required skills</p><span className="text-xs text-slate-400">{draft.requiredSkills.length} signals</span></div><div className="flex flex-wrap gap-2">{draft.requiredSkills.map(skill => <Badge key={skill} className="border-0 bg-[#e8f1f6] px-2.5 py-1 text-[#315b73] hover:bg-[#e8f1f6]">{skill}<button aria-label={`Remove ${skill}`} onClick={() => setDraft({ ...draft, requiredSkills: draft.requiredSkills.filter(item => item !== skill) })}><X className="ml-1 h-3 w-3" /></button></Badge>)}{draft.requiredSkills.length === 0 && <span className="text-sm text-slate-400">No explicit skills detected yet.</span>}</div><div className="mt-3 flex gap-2"><Input value={newSkill} onChange={e => setNewSkill(e.target.value)} onKeyDown={e => { if (e.key === "Enter") { e.preventDefault(); addSkill(); } }} placeholder="Add a required skill" className="h-9 max-w-xs" /><Button type="button" variant="outline" size="sm" onClick={addSkill}><Plus className="mr-1 h-3.5 w-3.5" />Add</Button></div></div>
    <div className="space-y-4 rounded-xl border border-slate-100 bg-[#fbfcfd] p-4"><div className="space-y-2"><Label className="text-xs text-slate-500">Role summary</Label><Textarea value={draft.summary} onChange={e => setDraft({ ...draft, summary: e.target.value })} className="min-h-20 bg-white text-sm" /></div><div className="grid gap-3 sm:grid-cols-2"><div className="space-y-2"><Label className="text-xs text-slate-500">Minimum years</Label><Input type="number" min={0} max={60} value={draft.minYearsExperience} onChange={e => setDraft({ ...draft, minYearsExperience: Number(e.target.value) || 0 })} className="h-9 bg-white" /></div><div className="space-y-2"><Label className="text-xs text-slate-500">Preferred skill</Label><div className="flex gap-2"><Input placeholder="e.g. AWS" className="h-9 bg-white" onKeyDown={e => { if (e.key === "Enter") { const value = e.currentTarget.value.trim(); if (value) setDraft({ ...draft, preferredSkills: [...draft.preferredSkills, value] }); e.currentTarget.value = ""; } }} /><Button type="button" variant="outline" size="sm" className="h-9" onClick={e => { const input = e.currentTarget.previousElementSibling as HTMLInputElement | null; const value = input?.value.trim(); if (value) setDraft({ ...draft, preferredSkills: [...draft.preferredSkills, value] }); if (input) input.value = ""; }}>Add</Button></div></div></div><div className="flex flex-wrap gap-2">{draft.preferredSkills.map(skill => <Badge key={skill} variant="outline" className="border-slate-200 text-slate-500">{skill}<button aria-label={`Remove preferred ${skill}`} onClick={() => setDraft({ ...draft, preferredSkills: draft.preferredSkills.filter(item => item !== skill) })}><X className="ml-1 h-3 w-3" /></button></Badge>)}</div><div className="grid gap-3 sm:grid-cols-2"><div className="space-y-2"><Label className="text-xs text-slate-500">Education requirement</Label><Input value={draft.education[0] || ""} onChange={e => setDraft({ ...draft, education: e.target.value ? [e.target.value] : [] })} placeholder="e.g. Bachelor's degree" className="h-9 bg-white" /></div><div className="space-y-2"><Label className="text-xs text-slate-500">Certification</Label><Input value={draft.certifications[0] || ""} onChange={e => setDraft({ ...draft, certifications: e.target.value ? [e.target.value] : [] })} placeholder="Optional certification" className="h-9 bg-white" /></div></div></div><div className="grid gap-3 sm:grid-cols-4">{([["skills", "Skills"], ["experience", "Experience"], ["education", "Education"], ["evidence", "Evidence"]] as const).map(([key, label]) => <div key={key} className="space-y-1.5"><Label className="text-[11px] text-slate-500">{label} %</Label><Input type="number" min={0} max={100} value={draft.weights[key]} onChange={e => setDraft({ ...draft, weights: { ...draft.weights, [key]: Number(e.target.value) || 0 } })} className="h-9" /></div>)}</div>
    <div className="flex items-center justify-between border-t border-slate-100 pt-4"><div><p className="text-xs font-semibold text-[#243b53]">Scoring weights</p><p className="mt-1 text-xs text-slate-400">Skills {draft.weights.skills}% · Experience {draft.weights.experience}% · Evidence {draft.weights.evidence}%</p></div><Button size="sm" disabled={update.isPending} onClick={() => update.mutate({ projectId, jobProfile: draft })}>{update.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <><Check className="mr-1.5 h-3.5 w-3.5" />Save profile</>}</Button></div>
  </CardContent></Card>;
}

function CandidateDrawer({ candidateId, onClose, onUpdated }: { candidateId: number; onClose: () => void; onUpdated: () => void }) {
  const { data, isLoading } = trpc.screening.getCandidate.useQuery({ candidateId });
  const utils = trpc.useUtils();
  const review = trpc.screening.updateReview.useMutation({ onSuccess: () => { toast.success("Candidate status updated"); utils.screening.getCandidate.invalidate({ candidateId }); onUpdated(); }, onError: error => toast.error(error.message) });
  const [notes, setNotes] = useState("");
  if (isLoading || !data) return <div className="fixed inset-y-0 right-0 z-50 flex w-full max-w-xl items-center justify-center border-l bg-white shadow-2xl"><Loader2 className="h-6 w-6 animate-spin text-[#2f80a0]" /></div>;
  const profile = data.profile;
  const result = data.result;
  const reviewStatus = data.review?.status ?? "unreviewed";
  return <div className="fixed inset-0 z-50 flex justify-end bg-[#102a43]/20 backdrop-blur-[2px]" onClick={onClose}><aside className="h-full w-full max-w-xl overflow-y-auto border-l border-slate-200 bg-[#fbfcfd] shadow-2xl" onClick={e => e.stopPropagation()}><div className="sticky top-0 z-10 flex items-center justify-between border-b border-slate-100 bg-white/95 px-6 py-4 backdrop-blur"><div><p className="text-xs font-semibold uppercase tracking-[0.16em] text-slate-400">Candidate profile</p><h2 className="mt-1 text-lg font-semibold text-[#243b53]">{profile?.fullName || data.candidate.displayId}</h2></div><Button variant="ghost" size="icon" onClick={onClose} aria-label="Close candidate details"><X className="h-5 w-5" /></Button></div><div className="space-y-5 p-6">
    <div className="flex items-center justify-between rounded-2xl bg-[#243b53] p-5 text-white"><div><p className="text-xs uppercase tracking-[0.16em] text-[#b8c9d8]">Overall match</p><p className="mt-1 text-4xl font-semibold">{result?.overallScore ?? "—"}<span className="text-lg text-[#b8c9d8]">/100</span></p></div><div className="rounded-full border-4 border-white/20 p-3"><Target className="h-7 w-7 text-[#8ed1c7]" /></div></div>
    <div className="grid gap-3 sm:grid-cols-2">{[["Skills match", result?.skillsScore], ["Experience", result?.experienceScore], ["Education", result?.educationScore], ["Evidence quality", result?.evidenceScore]].map(([label, value]) => <div key={String(label)} className="rounded-xl border border-slate-100 bg-white p-4"><div className="flex justify-between text-sm"><span className="text-slate-500">{label}</span><span className={`font-semibold ${scoreTone(Number(value) || 0)}`}>{value ?? "—"}</span></div><Progress value={Number(value) || 0} className="mt-3 h-1.5" /></div>)}</div>
    <Card className="border-0 bg-white shadow-sm"><CardHeader className="pb-3"><CardTitle className="text-sm text-[#243b53]">Evidence found</CardTitle></CardHeader><CardContent className="space-y-3">{Array.isArray(result?.matchedRequirements) && result.matchedRequirements.length > 0 ? result.matchedRequirements.map(item => <div key={String(item)} className="flex gap-2 text-sm text-slate-600"><Check className="mt-0.5 h-4 w-4 shrink-0 text-emerald-500" />{String(item)}</div>) : <p className="text-sm text-slate-400">No matched requirements were recorded.</p>}</CardContent></Card>
    {Array.isArray(result?.missingRequirements) && result.missingRequirements.length > 0 && <Card className="border-0 bg-white shadow-sm"><CardHeader className="pb-3"><CardTitle className="text-sm text-[#243b53]">Gaps to review</CardTitle></CardHeader><CardContent className="space-y-3">{result.missingRequirements.slice(0, 8).map(item => <div key={String(item)} className="flex gap-2 text-sm text-slate-600"><AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-amber-500" />{String(item)}</div>)}</CardContent></Card>}
    {Array.isArray(result?.uncertaintyFlags) && result.uncertaintyFlags.length > 0 && <div className="rounded-xl border border-amber-100 bg-amber-50 p-4 text-sm text-amber-800"><div className="mb-2 flex items-center gap-2 font-semibold"><CircleHelp className="h-4 w-4" />Review flags</div><ul className="space-y-1">{result.uncertaintyFlags.map(item => <li key={String(item)}>• {String(item)}</li>)}</ul></div>}
    <div className="space-y-3"><p className="text-xs font-semibold uppercase tracking-[0.14em] text-slate-400">Recruiter decision</p><div className="flex flex-wrap gap-2">{[["reviewed", "Mark reviewed"], ["shortlisted", "Shortlist"], ["archived", "Archive"]].map(([status, label]) => <Button key={status} size="sm" variant={reviewStatus === status ? "default" : "outline"} onClick={() => review.mutate({ candidateId, status: status as "reviewed" | "shortlisted" | "archived" })}>{reviewStatus === status && <Check className="mr-1.5 h-3.5 w-3.5" />}{label}</Button>)}</div><Textarea value={notes || data.review?.notes || ""} onChange={e => setNotes(e.target.value)} placeholder="Add a private recruiter note…" className="min-h-24 bg-white" /><Button variant="outline" size="sm" onClick={() => review.mutate({ candidateId, status: reviewStatus, notes })}>Save note</Button></div>
    <p className="flex items-start gap-2 border-t border-slate-100 pt-4 text-xs leading-5 text-slate-400"><ShieldCheck className="mt-0.5 h-3.5 w-3.5 shrink-0" />AI output is advisory. Review the original resume and apply consistent, job-related criteria before making decisions.</p>
  </div></aside></div>;
}

function ProjectSettings({ project, onSaved, onDeleted }: { project: any; onSaved: () => void; onDeleted: () => void }) {
  const [editing, setEditing] = useState(false);
  const [title, setTitle] = useState(project.title);
  const [description, setDescription] = useState(project.jobDescription || "");
  const utils = trpc.useUtils();
  const update = trpc.screening.updateProjectDetails.useMutation({ onSuccess: async () => { toast.success("Project details updated"); await utils.screening.listProjects.invalidate(); setEditing(false); onSaved(); }, onError: error => toast.error(error.message) });
  const remove = trpc.screening.deleteProject.useMutation({ onSuccess: async () => { toast.success("Project deleted"); await utils.screening.listProjects.invalidate(); onDeleted(); }, onError: error => toast.error(error.message) });
  if (!editing) return <div className="flex items-center gap-2"><Button variant="outline" size="sm" onClick={() => setEditing(true)}>Edit project</Button><Button variant="ghost" size="sm" className="text-slate-400 hover:text-red-600" onClick={() => { if (window.confirm("Delete this project and its candidate data?")) remove.mutate({ projectId: project.id }); }}>Delete</Button></div>;
  return <Card className="border-0 bg-white shadow-[0_8px_30px_rgba(31,56,78,0.06)]"><CardHeader><CardTitle className="text-base text-[#243b53]">Edit project details</CardTitle></CardHeader><CardContent className="space-y-4"><div className="space-y-2"><Label htmlFor="edit-project-title">Role title</Label><Input id="edit-project-title" value={title} onChange={e => setTitle(e.target.value)} /></div><div className="space-y-2"><Label htmlFor="edit-project-description">Job description</Label><Textarea id="edit-project-description" value={description} onChange={e => setDescription(e.target.value)} className="min-h-36" /></div><div className="flex justify-end gap-2"><Button variant="ghost" onClick={() => setEditing(false)}>Cancel</Button><Button disabled={update.isPending || title.trim().length < 2 || description.trim().length < 40} onClick={() => update.mutate({ projectId: project.id, title, jobDescription: description })}>{update.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : "Save changes"}</Button></div></CardContent></Card>;
}

function ProjectWorkspace({ project, onBack }: { project: any; onBack: () => void }) {
  const profile = getProfile(project.jobProfile);
  const [selectedCandidate, setSelectedCandidate] = useState<number | null>(null);
  const [query, setQuery] = useState("");
  const [sortBy, setSortBy] = useState<"score" | "name">("score");
  const fileRef = useRef<HTMLInputElement>(null);
  const utils = trpc.useUtils();
  const { data: candidates, isLoading } = trpc.screening.listCandidates.useQuery({ projectId: project.id });
  const upload = trpc.screening.uploadResume.useMutation({ onSuccess: result => { toast.success(`${result.displayId} screened at ${result.score}/100`); utils.screening.listCandidates.invalidate({ projectId: project.id }); utils.screening.listProjects.invalidate(); }, onError: error => toast.error(error.message) });
  const retry = trpc.screening.retryScreening.useMutation({ onSuccess: result => { toast.success(`Screening retried at ${result.score}/100`); utils.screening.listCandidates.invalidate({ projectId: project.id }); }, onError: error => toast.error(error.message) });
  const updateProfile = () => { utils.screening.getProject.invalidate({ projectId: project.id }); utils.screening.listProjects.invalidate(); };
  const visibleCandidates = useMemo(() => sortCandidates((candidates ?? []).filter((candidate: any) => {
    const name = candidate.profile?.fullName || candidate.displayId;
    return `${name} ${candidate.originalFilename}`.toLowerCase().includes(query.toLowerCase());
  }) as any[], sortBy), [candidates, query, sortBy]);
  const readFile = (file: File) => new Promise<string>((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(String(reader.result).split(",")[1] || ""); reader.onerror = () => reject(reader.error); reader.readAsDataURL(file); });
  const uploadFiles = async (files: FileList | null) => { if (!files) return; for (const file of Array.from(files)) { try { const fileData = await readFile(file); await upload.mutateAsync({ projectId: project.id, filename: file.name, mimeType: file.type || (file.name.endsWith(".pdf") ? "application/pdf" : "application/vnd.openxmlformats-officedocument.wordprocessingml.document"), fileData }); } catch { /* toast handled by mutation */ } } };
  const screenedCount = (candidates ?? []).filter((c: any) => c.processingStatus === "screened").length;
  const average = screenedCount ? Math.round((candidates ?? []).filter((c: any) => c.result).reduce((sum: number, c: any) => sum + (c.result?.overallScore || 0), 0) / screenedCount) : 0;
  return <div className="space-y-6"><div className="flex flex-wrap items-start justify-between gap-4"><div><button onClick={onBack} className="mb-3 flex items-center gap-1.5 text-sm text-slate-400 transition-colors hover:text-[#243b53]"><ArrowLeft className="h-4 w-4" />All hiring projects</button><div className="flex items-center gap-3"><div className="rounded-2xl bg-[#e8f1f6] p-3 text-[#2f6683]"><BriefcaseBusiness className="h-5 w-5" /></div><div><h1 className="text-2xl font-semibold tracking-tight text-[#243b53]">{project.title}</h1><p className="mt-1 text-sm text-slate-500">Candidate screening workspace <span className="mx-1 text-slate-300">·</span> SDG 8 aligned decision support</p></div></div></div><Button onClick={() => fileRef.current?.click()} disabled={upload.isPending} className="bg-[#243b53] hover:bg-[#1c2f43]"><UploadCloud className="mr-2 h-4 w-4" />{upload.isPending ? "Screening resumes…" : "Upload resumes"}</Button><input ref={fileRef} type="file" accept=".pdf,.docx,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document" multiple className="hidden" onChange={e => { void uploadFiles(e.target.files); e.currentTarget.value = ""; }} /></div>
    <div className="grid gap-4 md:grid-cols-3"><StatCard label="Resumes screened" value={screenedCount} detail={`${candidates?.length ?? 0} files in this project`} icon={Users} accent="bg-[#e8f1f6] text-[#2f6683]" /><StatCard label="Average match" value={screenedCount ? `${average}/100` : "—"} detail="Across available evidence" icon={Target} accent="bg-[#e8f5ef] text-[#2e7d5b]" /><StatCard label="Shortlisted" value={(candidates ?? []).filter((c: any) => c.review?.status === "shortlisted").length} detail="Manual recruiter decisions" icon={Check} accent="bg-[#fff5df] text-[#b8791c]" /></div>
    <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_340px]"><div className="min-w-0 space-y-4"><Card className="border-0 bg-white shadow-[0_8px_30px_rgba(31,56,78,0.06)]"><CardHeader className="flex flex-row items-center justify-between gap-4 pb-4"><div><CardTitle className="text-base text-[#243b53]">Ranked candidates</CardTitle><CardDescription>Sorted by explainable match score. Scores are not automatic hiring decisions.</CardDescription></div><div className="flex items-center gap-2"><div className="relative w-44"><Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" /><Input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search candidates" className="h-9 pl-9" /></div><select aria-label="Sort candidates" value={sortBy} onChange={e => setSortBy(e.target.value as "score" | "name")} className="h-9 rounded-md border border-input bg-background px-2 text-xs text-slate-600"><option value="score">Highest match</option><option value="name">Name A–Z</option></select></div></CardHeader><Separator /><CardContent className="p-0"><div className="overflow-x-auto"><table className="w-full min-w-[680px] text-sm"><thead><tr className="border-b border-slate-100 text-left text-[10px] font-semibold uppercase tracking-[0.14em] text-slate-400"><th className="px-5 py-3">Candidate</th><th className="px-4 py-3">Match</th><th className="px-4 py-3">Skills</th><th className="px-4 py-3">Experience</th><th className="px-4 py-3">Status</th><th className="px-5 py-3"></th></tr></thead><tbody>{isLoading ? <tr><td colSpan={6} className="px-5 py-12 text-center text-slate-400"><Loader2 className="mx-auto mb-2 h-5 w-5 animate-spin" />Loading candidate results…</td></tr> : visibleCandidates.length === 0 ? <tr><td colSpan={6} className="px-5 py-14 text-center"><FileText className="mx-auto mb-3 h-8 w-8 text-slate-300" /><p className="font-medium text-[#243b53]">No candidates yet</p><p className="mt-1 text-sm text-slate-400">Upload PDF or DOCX resumes to begin screening.</p></td></tr> : visibleCandidates.map((candidate: any) => { const score = candidate.result?.overallScore ?? 0; return <tr key={candidate.id} className="group border-b border-slate-50 transition-colors hover:bg-[#f7fafc]"><td className="px-5 py-4"><button className="text-left" onClick={() => setSelectedCandidate(candidate.id)}><p className="font-semibold text-[#243b53] group-hover:text-[#2f80a0]">{candidate.profile?.fullName || candidate.displayId}</p><p className="mt-1 text-xs text-slate-400">{candidate.profile?.headline || candidate.originalFilename}</p></button></td><td className="px-4 py-4"><div className="flex items-center gap-3"><span className={`w-10 text-lg font-semibold ${scoreTone(score)}`}>{candidate.processingStatus === "screened" ? score : "—"}</span><div className="w-20"><div className="h-1.5 overflow-hidden rounded-full bg-slate-100"><div className={`h-full rounded-full ${scoreBar(score)}`} style={{ width: `${score}%` }} /></div></div></div></td><td className="px-4 py-4 text-slate-600">{candidate.result?.skillsScore ?? "—"}<span className="text-slate-300">/100</span></td><td className="px-4 py-4 text-slate-600">{candidate.result?.experienceScore ?? "—"}<span className="text-slate-300">/100</span></td><td className="px-4 py-4">{candidate.processingStatus === "failed" ? <div className="flex items-center gap-2"><Badge className="border-0 bg-red-50 text-red-700">Failed</Badge><Button variant="ghost" size="sm" className="h-7 px-2 text-xs" disabled={retry.isPending} onClick={() => retry.mutate({ candidateId: candidate.id })}>Retry</Button></div> : candidate.review?.status === "shortlisted" ? <Badge className="border-0 bg-emerald-50 text-emerald-700">Shortlisted</Badge> : candidate.processingStatus === "screened" ? <Badge variant="outline" className="border-slate-200 text-slate-500">Needs review</Badge> : <Badge className="border-0 bg-amber-50 text-amber-700">Processing</Badge>}</td><td className="px-5 py-4 text-right"><Button variant="ghost" size="icon" aria-label="Open candidate details" onClick={() => setSelectedCandidate(candidate.id)}><ChevronRight className="h-4 w-4 text-slate-400" /></Button></td></tr>; })}</tbody></table></div></CardContent></Card></div><div><JobProfileCard projectId={project.id} profile={profile} onUpdated={updateProfile} /></div></div>
    <ProjectSettings project={project} onSaved={updateProfile} onDeleted={onBack} />
    {selectedCandidate && <CandidateDrawer candidateId={selectedCandidate} onClose={() => setSelectedCandidate(null)} onUpdated={() => utils.screening.listCandidates.invalidate({ projectId: project.id })} />}
  </div>;
}

export default function Home() {
  const { user } = useAuth();
  const { data: projects, isLoading } = trpc.screening.listProjects.useQuery();
  const [selectedProjectId, setSelectedProjectId] = useState<number | null>(null);
  const [creating, setCreating] = useState(false);
  const selectedProject = (projects ?? []).find(project => project.id === selectedProjectId);
  const projectCount = projects?.length ?? 0;
  if (selectedProject) return <DashboardLayout><div className="min-h-screen bg-[#f4f7fa] p-4 sm:p-8"><ProjectWorkspace project={selectedProject} onBack={() => setSelectedProjectId(null)} /></div></DashboardLayout>;
  return <DashboardLayout><div className="min-h-screen bg-[#f4f7fa] p-4 sm:p-8"><div className="mx-auto max-w-[1440px] space-y-8"><header className="flex flex-wrap items-start justify-between gap-5"><div className="flex items-start gap-3"><AppMark /><div><p className="text-xs font-semibold uppercase tracking-[0.2em] text-[#6b8296]">Recruiting intelligence</p><h1 className="mt-1 text-3xl font-semibold tracking-tight text-[#243b53]">Good morning{user?.name ? `, ${user.name.split(" ")[0]}` : ""}.</h1><p className="mt-2 max-w-xl text-sm leading-6 text-slate-500">Screen faster, keep criteria transparent, and give every candidate a consistent first review.</p></div></div><Button onClick={() => setCreating(true)} className="bg-[#243b53] shadow-sm hover:bg-[#1c2f43]"><Plus className="mr-2 h-4 w-4" />New hiring project</Button></header>
    {creating ? <NewProject onCreated={id => { setCreating(false); setSelectedProjectId(id); }} onCancel={() => setCreating(false)} /> : <><div className="grid gap-4 md:grid-cols-3"><StatCard label="Active projects" value={projectCount} detail="Roles in your workspace" icon={BriefcaseBusiness} accent="bg-[#e8f1f6] text-[#2f6683]" /><StatCard label="Candidates reviewed" value="0" detail="Across all projects" icon={Users} accent="bg-[#e8f5ef] text-[#2e7d5b]" /><StatCard label="Fairness guardrails" value="On" detail="Protected traits excluded" icon={ShieldCheck} accent="bg-[#fff5df] text-[#b8791c]" /></div><section><div className="mb-4 flex items-end justify-between"><div><h2 className="text-lg font-semibold text-[#243b53]">Your hiring projects</h2><p className="mt-1 text-sm text-slate-500">Create a role to turn resumes into a reviewable shortlist.</p></div><div className="hidden items-center gap-2 text-xs text-slate-400 sm:flex"><Filter className="h-3.5 w-3.5" />Recently updated</div></div>{isLoading ? <Card className="border-0 bg-white"><CardContent className="flex items-center justify-center gap-2 p-16 text-sm text-slate-400"><Loader2 className="h-4 w-4 animate-spin" />Loading workspace…</CardContent></Card> : projectCount === 0 ? <Card className="border-0 bg-white shadow-[0_8px_30px_rgba(31,56,78,0.06)]"><CardContent className="p-0"><div className="grid gap-8 p-8 md:grid-cols-[1.1fr_0.9fr] md:p-12"><div><Badge variant="outline" className="border-[#cfe1eb] bg-[#f5f9fc] text-[#2f6683]">Built for human review</Badge><h3 className="mt-5 max-w-md text-3xl font-semibold tracking-tight text-[#243b53]">Your next great hire starts with a clearer first pass.</h3><p className="mt-4 max-w-lg text-sm leading-7 text-slate-500">Paste a job description, upload a resume batch, and inspect the evidence behind each ranking. No black-box rejections. No protected-attribute scoring.</p><Button onClick={() => setCreating(true)} variant="outline" className="mt-7 border-[#243b53] text-[#243b53] hover:bg-[#f4f8fb]"><Sparkles className="mr-2 h-4 w-4" />Set up your first role</Button></div><div className="relative overflow-hidden rounded-2xl bg-[#eef5f8] p-6"><div className="absolute -right-8 -top-8 h-32 w-32 rounded-full bg-[#d6e9ef]" /><div className="relative space-y-3"><p className="text-xs font-semibold uppercase tracking-[0.18em] text-[#6b8296]">Screening workflow</p>{[["01", "Define the role", "Normalize requirements"], ["02", "Upload resumes", "Parse structured evidence"], ["03", "Review the shortlist", "Keep decisions human"]].map(([number, title, detail]) => <div key={number} className="flex gap-3 rounded-xl bg-white/75 p-3"><span className="font-mono text-xs text-[#2f80a0]">{number}</span><div><p className="text-sm font-semibold text-[#243b53]">{title}</p><p className="mt-0.5 text-xs text-slate-500">{detail}</p></div></div>)}</div></div></div></CardContent></Card> : <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">{projects?.map(project => <button key={project.id} onClick={() => setSelectedProjectId(project.id)} className="text-left"><Card className="h-full border-0 bg-white shadow-[0_8px_30px_rgba(31,56,78,0.06)] transition-all hover:-translate-y-0.5 hover:shadow-[0_12px_36px_rgba(31,56,78,0.12)]"><CardContent className="p-5"><div className="flex items-start justify-between"><div className="rounded-xl bg-[#e8f1f6] p-2.5 text-[#2f6683]"><BriefcaseBusiness className="h-4 w-4" /></div><ArrowUpRight className="h-4 w-4 text-slate-300" /></div><h3 className="mt-6 font-semibold text-[#243b53]">{project.title}</h3><div className="mt-3 flex items-center gap-2 text-xs text-slate-400"><Users className="h-3.5 w-3.5" />{project.candidateCount ?? 0} candidates</div><div className="mt-5 flex items-center justify-between border-t border-slate-100 pt-4"><Badge variant="outline" className="border-slate-200 text-slate-500">{project.status === "complete" ? "Ready to review" : "Draft"}</Badge><span className="text-xs text-slate-400">Open workspace <ChevronRight className="inline h-3.5 w-3.5" /></span></div></CardContent></Card></button>)}</div>}</section><footer className="flex items-center gap-2 border-t border-slate-200 pt-5 text-xs text-slate-400"><ShieldCheck className="h-3.5 w-3.5" />Transparent AI decision support for recruitment · Sensitive attributes are not used in scoring.</footer></>}</div></div></DashboardLayout>;
}
