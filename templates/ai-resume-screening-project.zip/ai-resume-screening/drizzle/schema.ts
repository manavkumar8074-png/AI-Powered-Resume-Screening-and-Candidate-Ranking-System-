import {
  index,
  int,
  json,
  longtext,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/mysql-core";

/** Core user table backing the existing Manus authentication flow. */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const hiringProjects = mysqlTable(
  "hiring_projects",
  {
    id: int("id").autoincrement().primaryKey(),
    ownerId: int("ownerId").notNull(),
    title: varchar("title", { length: 180 }).notNull(),
    jobDescription: longtext("jobDescription").notNull(),
    jobProfile: json("jobProfile"),
    status: mysqlEnum("status", ["draft", "screening", "complete", "archived"])
      .default("draft")
      .notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    ownerIdx: index("hiring_projects_owner_idx").on(table.ownerId),
    statusIdx: index("hiring_projects_status_idx").on(table.status),
  }),
);

export const candidates = mysqlTable(
  "candidates",
  {
    id: int("id").autoincrement().primaryKey(),
    projectId: int("projectId").notNull(),
    originalFilename: varchar("originalFilename", { length: 255 }).notNull(),
    displayId: varchar("displayId", { length: 32 }).notNull(),
    storageKey: varchar("storageKey", { length: 500 }).notNull(),
    mimeType: varchar("mimeType", { length: 120 }).notNull(),
    fileSize: int("fileSize").notNull(),
    extractedText: longtext("extractedText"),
    processingStatus: mysqlEnum("processingStatus", [
      "queued",
      "parsing",
      "screened",
      "failed",
    ])
      .default("queued")
      .notNull(),
    processingError: text("processingError"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    projectIdx: index("candidates_project_idx").on(table.projectId),
    statusIdx: index("candidates_status_idx").on(table.processingStatus),
    displayIdUnique: uniqueIndex("candidates_project_display_id_unique").on(
      table.projectId,
      table.displayId,
    ),
  }),
);

export const candidateProfiles = mysqlTable(
  "candidate_profiles",
  {
    id: int("id").autoincrement().primaryKey(),
    candidateId: int("candidateId").notNull().unique(),
    fullName: varchar("fullName", { length: 180 }),
    email: varchar("email", { length: 320 }),
    location: varchar("location", { length: 180 }),
    headline: varchar("headline", { length: 255 }),
    skills: json("skills"),
    experience: json("experience"),
    education: json("education"),
    certifications: json("certifications"),
    totalYearsExperience: int("totalYearsExperience"),
    extractionConfidence: int("extractionConfidence"),
    modelId: varchar("modelId", { length: 120 }),
    schemaVersion: varchar("schemaVersion", { length: 40 }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    candidateIdx: index("candidate_profiles_candidate_idx").on(table.candidateId),
  }),
);

export const screeningResults = mysqlTable(
  "screening_results",
  {
    id: int("id").autoincrement().primaryKey(),
    candidateId: int("candidateId").notNull().unique(),
    overallScore: int("overallScore").notNull(),
    skillsScore: int("skillsScore").notNull(),
    experienceScore: int("experienceScore").notNull(),
    educationScore: int("educationScore").notNull(),
    evidenceScore: int("evidenceScore").notNull(),
    matchedRequirements: json("matchedRequirements"),
    missingRequirements: json("missingRequirements"),
    evidenceSnippets: json("evidenceSnippets"),
    uncertaintyFlags: json("uncertaintyFlags"),
    modelId: varchar("modelId", { length: 120 }),
    promptVersion: varchar("promptVersion", { length: 40 }),
    generatedAt: timestamp("generatedAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    scoreIdx: index("screening_results_score_idx").on(table.overallScore),
  }),
);

export const candidateReviews = mysqlTable(
  "candidate_reviews",
  {
    id: int("id").autoincrement().primaryKey(),
    candidateId: int("candidateId").notNull().unique(),
    reviewerId: int("reviewerId").notNull(),
    status: mysqlEnum("status", ["unreviewed", "reviewed", "shortlisted", "archived"])
      .default("unreviewed")
      .notNull(),
    notes: text("notes"),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => ({
    reviewerIdx: index("candidate_reviews_reviewer_idx").on(table.reviewerId),
  }),
);

export const auditEvents = mysqlTable(
  "audit_events",
  {
    id: int("id").autoincrement().primaryKey(),
    ownerId: int("ownerId").notNull(),
    projectId: int("projectId"),
    candidateId: int("candidateId"),
    eventType: varchar("eventType", { length: 80 }).notNull(),
    metadata: json("metadata"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => ({
    ownerIdx: index("audit_events_owner_idx").on(table.ownerId),
    projectIdx: index("audit_events_project_idx").on(table.projectId),
    candidateIdx: index("audit_events_candidate_idx").on(table.candidateId),
  }),
);

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type HiringProject = typeof hiringProjects.$inferSelect;
export type InsertHiringProject = typeof hiringProjects.$inferInsert;
export type Candidate = typeof candidates.$inferSelect;
export type InsertCandidate = typeof candidates.$inferInsert;
export type CandidateProfile = typeof candidateProfiles.$inferSelect;
export type InsertCandidateProfile = typeof candidateProfiles.$inferInsert;
export type ScreeningResult = typeof screeningResults.$inferSelect;
export type InsertScreeningResult = typeof screeningResults.$inferInsert;
export type CandidateReview = typeof candidateReviews.$inferSelect;
export type InsertCandidateReview = typeof candidateReviews.$inferInsert;
export type AuditEvent = typeof auditEvents.$inferSelect;
export type InsertAuditEvent = typeof auditEvents.$inferInsert;