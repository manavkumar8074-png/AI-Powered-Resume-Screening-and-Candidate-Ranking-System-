CREATE TABLE `audit_events` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`projectId` int,
	`candidateId` int,
	`eventType` varchar(80) NOT NULL,
	`metadata` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `audit_events_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `candidate_profiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`candidateId` int NOT NULL,
	`fullName` varchar(180),
	`email` varchar(320),
	`location` varchar(180),
	`headline` varchar(255),
	`skills` json,
	`experience` json,
	`education` json,
	`certifications` json,
	`totalYearsExperience` int,
	`extractionConfidence` int,
	`modelId` varchar(120),
	`schemaVersion` varchar(40),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `candidate_profiles_id` PRIMARY KEY(`id`),
	CONSTRAINT `candidate_profiles_candidateId_unique` UNIQUE(`candidateId`)
);
--> statement-breakpoint
CREATE TABLE `candidate_reviews` (
	`id` int AUTO_INCREMENT NOT NULL,
	`candidateId` int NOT NULL,
	`reviewerId` int NOT NULL,
	`status` enum('unreviewed','reviewed','shortlisted','archived') NOT NULL DEFAULT 'unreviewed',
	`notes` text,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `candidate_reviews_id` PRIMARY KEY(`id`),
	CONSTRAINT `candidate_reviews_candidateId_unique` UNIQUE(`candidateId`)
);
--> statement-breakpoint
CREATE TABLE `candidates` (
	`id` int AUTO_INCREMENT NOT NULL,
	`projectId` int NOT NULL,
	`originalFilename` varchar(255) NOT NULL,
	`displayId` varchar(32) NOT NULL,
	`storageKey` varchar(500) NOT NULL,
	`mimeType` varchar(120) NOT NULL,
	`fileSize` int NOT NULL,
	`extractedText` longtext,
	`processingStatus` enum('queued','parsing','screened','failed') NOT NULL DEFAULT 'queued',
	`processingError` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `candidates_id` PRIMARY KEY(`id`),
	CONSTRAINT `candidates_project_display_id_unique` UNIQUE(`projectId`,`displayId`)
);
--> statement-breakpoint
CREATE TABLE `hiring_projects` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`title` varchar(180) NOT NULL,
	`jobDescription` longtext NOT NULL,
	`jobProfile` json,
	`status` enum('draft','screening','complete','archived') NOT NULL DEFAULT 'draft',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `hiring_projects_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `screening_results` (
	`id` int AUTO_INCREMENT NOT NULL,
	`candidateId` int NOT NULL,
	`overallScore` int NOT NULL,
	`skillsScore` int NOT NULL,
	`experienceScore` int NOT NULL,
	`educationScore` int NOT NULL,
	`evidenceScore` int NOT NULL,
	`matchedRequirements` json,
	`missingRequirements` json,
	`evidenceSnippets` json,
	`uncertaintyFlags` json,
	`modelId` varchar(120),
	`promptVersion` varchar(40),
	`generatedAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `screening_results_id` PRIMARY KEY(`id`),
	CONSTRAINT `screening_results_candidateId_unique` UNIQUE(`candidateId`)
);
--> statement-breakpoint
CREATE TABLE `users` (
	`id` int AUTO_INCREMENT NOT NULL,
	`openId` varchar(64) NOT NULL,
	`name` text,
	`email` varchar(320),
	`loginMethod` varchar(64),
	`role` enum('user','admin') NOT NULL DEFAULT 'user',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`lastSignedIn` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `users_id` PRIMARY KEY(`id`),
	CONSTRAINT `users_openId_unique` UNIQUE(`openId`)
);
--> statement-breakpoint
CREATE INDEX `audit_events_owner_idx` ON `audit_events` (`ownerId`);--> statement-breakpoint
CREATE INDEX `audit_events_project_idx` ON `audit_events` (`projectId`);--> statement-breakpoint
CREATE INDEX `audit_events_candidate_idx` ON `audit_events` (`candidateId`);--> statement-breakpoint
CREATE INDEX `candidate_profiles_candidate_idx` ON `candidate_profiles` (`candidateId`);--> statement-breakpoint
CREATE INDEX `candidate_reviews_reviewer_idx` ON `candidate_reviews` (`reviewerId`);--> statement-breakpoint
CREATE INDEX `candidates_project_idx` ON `candidates` (`projectId`);--> statement-breakpoint
CREATE INDEX `candidates_status_idx` ON `candidates` (`processingStatus`);--> statement-breakpoint
CREATE INDEX `hiring_projects_owner_idx` ON `hiring_projects` (`ownerId`);--> statement-breakpoint
CREATE INDEX `hiring_projects_status_idx` ON `hiring_projects` (`status`);--> statement-breakpoint
CREATE INDEX `screening_results_score_idx` ON `screening_results` (`overallScore`);